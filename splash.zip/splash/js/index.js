function onload(){
    //$('#logout').hide();

}

function login(){
    
    //$('#loginform').hide();
    //$('.user').hide();
    
    // var username = $('#username').val();
    // if(username == "admin"){
    //     window.location.hash = '#admin'; 
    // }else{
    //     window.location.hash = '#pickup'; 
    //}
    
}

$('#submitbtn').click(function(e){
    e.preventDefault();
    // Code goes here
});

onload();


$(document).ready(function(){
    $("#logout").hide();
    //$("#logout").show();
    $("#login").click(function(){
        $("#logout").toggle();
        $('#loginform').hide();
        var username = $('#username').val();
        if(username == "admin"){
            $('.adminclass').show();
            $('.user').hide();
            window.location.hash = '#admin'; 
        }else{
            $('.adminclass').hide();
            $('.user').show();
            window.location.hash = '#pickup'; 
        }
    });

    $("#logout").click(function(){ 
        $("#logout").hide();  
        $("#loginform").toggle();
    });

});